# ROADMAP

Estado del proyecto y próximos pasos.

## Estado actual (v1.0)

Funcional de punta a punta:

- [x] Front vanilla (HTML/CSS/JS) con input de HU, cantidad e instrucciones.
- [x] Lectura de la HU desde Azure DevOps (`GET /api/hu/{id}`).
- [x] Generación de casos con LLM local (Ollama, `qwen2.5:7b-instruct`, `format=json`).
- [x] Tabla editable de casos (título, prioridad, tipo, precondiciones, pasos).
- [x] Creación de `Test Case` en Azure DevOps enlazados a la HU (`POST /api/create`).
- [x] **Modo demo**: funciona sin Azure DevOps (HU de ejemplo + creación simulada), con banner en el front.
- [x] **Barra de progreso en vivo**: streaming SSE desde Ollama (tokens, velocidad, tiempo transcurrido).
- [x] **Exactitud de cantidad**: recorte si el modelo se pasa y reintento si faltan.
- [x] **Prompt adaptativo**: mínimo de pasos según cantidad y honor de "N pasos" explícito del QA.
- [x] **Pasar a GPT / Importar**: exporta HU+casos a `.md` con plantilla y bloque JSON, y re-importa la mejora.
- [x] **Probar conexión Azure**: botón que valida org + PAT + proyecto + permisos Work Items.
- [x] Prueba end-to-end en modo demo: `/api/generate-stream` con 2 casos ≈ 52 s (6.8 tokens/s) en CPU.
- [x] Manejo de errores con `detail` legible (front usa `alert`).
- [x] `docker-compose.yml` (backend + ollama), `.env.example`, README, AGENTS.md.

## Pruebas realizadas

- `python -m py_compile` sobre los 4 módulos del backend: OK.
- `docker compose config --quiet`: OK.
- Lógica pura de `steps_to_tcm_html` y `_parse_json` verificada con un script standalone: OK.
- **Pendiente (bloqueante para uso real):** prueba end-to-end contra **Azure DevOps real** — llenar `.env` con org/proyecto/PAT reales y usar el botón "Probar conexión Azure" + crear un Test Case real. Mientras tanto todo se valida en modo demo.

## Próximos pasos sugeridos

### Calidad del LLM
- [ ] Probar con HU reales y ajustar el prompt (ej. pedir tipos de prueba específicos).
- [ ] Ajustar `OLLAMA_TEMPERATURE`/`OLLAMA_MAX_TOKENS` si los casos salen repetidos o truncados.
- [ ] Evaluar `qwen2.5:3b` como fallback rápido cuando la RAM esté justa.

### Funcionalidad
- [ ] Exportar casos a JSON/CSV.
- [ ] Verificar si el work item ya existe (evitar duplicados) antes de crear.
- [ ] Batch: crear casos en paralelo o en una sola llamada (hoy es secuencial, `main.py:create`).
- [ ] Marcar en el front qué casos se crearon OK vs fallaron (hoy solo devuelve error global a mitad).
- [ ] Soporte para conectar a Azure DevOps Server (on-prem) cambiando la URL base.

### Tests automatizados
- [ ] Suite `pytest` para `azure_client` (mock httpx) y `llm_client` (mock respuesta de Ollama).
- [ ] Test del prompt builder y del normalizador con muestras realistas del modelo.

### Infra / DX
- [ ] Script `run.ps1` que cree el `.env`, levante compose y abra el navegador.
- [ ] Healthcheck de Ollama en el compose para que el backend arranque solo cuando el modelo esté listo.
- [ ] Evaluar `qwen2.5:3b` como opción rápida (2-3x más veloz en CPU) si el QA prefiere velocidad sobre calidad.
- [ ] Considerar modelos más grandes (`qwen2.5:14b`) solo si el usuario sube a 16 GB de RAM.

## Regla importante

Antes de tocar el formato TCM (`steps_to_tcm_html`) o el tipo de relación (`Microsoft.VSTS.Common.Tests`), probar contra Azure DevOps real, porque son los puntos que romperían la creación de casos en la plataforma.